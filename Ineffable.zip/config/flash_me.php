<?php 
/**
 * Change this /path if you load assets from local
 * example 'css' => asset('/css/app.css'),
 */
return [
	'css' => 'https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.1.5/css/iziToast.min.css',
	'js' => 'https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.1.5/js/iziToast.min.js',
];