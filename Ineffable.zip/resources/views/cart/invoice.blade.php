@extends('customer.layout.master')

@section('content')
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Invoice</h2>
                    <ul class="nav navbar-right panel_toolbox">
          
                      <li class="dropdown">
                        
                        <ul class="dropdown-menu" role="menu">
                          
                        </ul>
                      </li>
                      
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <section class="content invoice">
                      <!-- title row -->
                      <div class="row">
                        <div class="col-xs-12 invoice-header">
                          <h1>
                                          <i class="fa fa-globe"></i> Invoice.
                                          
                                      </h1>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- info row -->
                      <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">
                          From
                          <address>
                                          <strong>CEVEL Admin</strong>
                                          <br>D.I.Yogyakarta
                                          <br>Sleman
                                          <br>Phone: 1 (804) 123-9876
                                          <br>Email: admin@cevelstore.com
                                      </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                          To
                          <address>
                                          <strong>{{ Auth::user()->name }}</strong>
                                          <br>{{ Auth::user()->email }}
                                      </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                          <b>Invoice #007612</b>
                          <br>
                          <br>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- Table row -->
                      <div class="row">
                        <div class="col-xs-12 table">
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Name Product </th>
                                <th>Quantity </th>
                                <th>Price </th>
                              </tr>
                            </thead>
                            <tbody>
                            @foreach($data as $key)
                              <tr>
                      
                                <td>{{ $key->name }}</td>
                                <td>{{ $key->qty }}</td>
                                <td>Rp {{ $key->price }}</td>
                              </tr>
                            @endforeach
                            </tbody>
                          </table>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <div class="row">
                        <!-- accepted payments column -->
                        <div class="col-xs-6">
                          <p class="lead">Payment Methods:</p>
                          
                          <img src="{{asset('backend/production/images/pmandiri.png')}}" alt="Visa">
                           <strong> 010101001110</strong><br><br>
                          <img src="{{asset('backend/production/images/pbni.png')}}" alt="Mastercard">
                           <strong> 919191928822</strong><br><br>
                          <img src="{{asset('backend/production/images/pbca.png')}}" alt="American Express">
                           <strong> 882901011000</strong><br><br>
                          
                        </div>
                        <!-- /.col -->
                        <div class="col-xs-6">
                          
                          <div class="table-responsive">
                            <table class="table">
                              <tbody>                              
                                <tr>
                                  <th>Item</th>
                                  <td>{{ Cart::count() }}</td>
                                </tr>
                                <tr>
                                  <th>Total</th>
                                  <td>Rp {{ Cart::subtotal() }}</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
                    <br><br><br>
                      <!-- this row will not appear when printing -->
                      <div class="row no-print">
                        <div class="col-xs-12">
                          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        @endsection