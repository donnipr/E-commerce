<?php $__env->startSection('content'); ?>

<div class="right_col" role="main">
 
    <div class="">
        <div class="page-title">
            <div class="title_left greentea">
                <h3>
                    Dashboard <small>Data Product </small>
                </h3>
            </div>
 
           
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2 class="greentea">List Data</h2>
                        
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <!-- content starts here -->
                            <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title">No </th>
                            <th class="column-title">Name </th>
                            <th class="column-title">Status</th>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                        <?php $no=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bajuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="even pointer">
                            <td class=" "><?php echo e($no++); ?></td>
                            <td class=" "><?php echo substr($bajuku->name,0,2); ?></td>
                            <td class=" "><?php echo e($bajuku->name); ?></td>
                            
                          
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      </div>
                        <!-- content ends here -->
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <?php if(flashMe()->ok()): ?>
        <?php echo flashMe_flash(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>