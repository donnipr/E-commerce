<?php $__env->startSection('content'); ?>

<div class="right_col" role="main">
 
    <div class="">
        <div class="page-title">
            <div class="title_left greentea">
                <h3>
                    Shopping Cart <small></small>
                </h3>
            </div>
 
            <div class="title_right">
            </div>
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <!-- content starts here -->
                            <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title">No </th>
                            <th class="column-title">Name Product </th>
                            <th class="column-title">Quantity </th>
                            <th class="column-title">Price </th>
                            <th class="column-title"></th>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                        <?php $no=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="even pointer">
                           <td class=" "><?php echo e($no++); ?></td>
                            <td class=" "><?php echo e($key->name); ?></td>
                            <td>
                           	<?php echo Form::open(['route'=>['cart.update',$key->rowId], 'method' => 'PUT']); ?>

                           		<input type="text" name="qty" value="<?php echo e($key->qty); ?>"> 
                           		<input type="submit" class="btn btn-xs btn-dark" value="ok">
                           	<?php echo Form::close(); ?>

                            </td>
                            <td class=" ">Rp <?php echo e($key->price); ?></td>
                            <td>
                            	<?php echo Form::open(['route'=>['cart.destroy',$key->rowId], 'method' => 'post']); ?>

                           		<input type="hidden" name="_token" value="<?= csrf_token(); ?>">
                           		<?php echo e(method_field('DELETE')); ?>

                           		<input class="btn btn-xs btn-round btn-dark" type="submit" value="X">
                           		<?php echo Form::close(); ?>

                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <tr class="greentea">
                          	<td></td>
                          	<td></td>
                          	<td><strong>Item : <?php echo e(Cart::count()); ?></strong></td>
                          	<td><strong>Total : Rp <?php echo e(Cart::subtotal()); ?></strong></td>
                          	<td></td>
                          </tr>
                        </tbody>
                      </table>
                      <a class="btn btn-success" href="<?php echo url(''); ?>" data-toggle="tooltip" data-placement="left" title="" data-original-title="">Go Shoping </a>
                      <a class="btn btn-dark" href="<?php echo e(route('invoice')); ?>" data-toggle="tooltip" data-placement="left" title="" data-original-title=""> Checkout </a>
                      </div>
                        <!-- content ends here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>