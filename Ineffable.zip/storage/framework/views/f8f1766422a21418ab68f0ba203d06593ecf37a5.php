<?php $__env->startSection('content'); ?>

<head>
<title></title>
<script type="text/javascript" src="<?php echo e(asset('tiny\assets\js\tinymce\tinymce.min.js')); ?>"></script>

<script type="text/javascript">
    tinymce.init({
        selector : "textarea",
        invalid_elements : "span"
    });
</script>

</head>
<body>
<div class="right_col" role="main">
 
    <div class="">
        <div class="page-title">
            <div class="title_left greentea">
                <h3>
                    Dashboard <small>Data Product </small>
                </h3>
            </div>
 
            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">
                       <br/><br/>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2 class="greentea">Update Data</h2>
                        <ul class="nav navbar-right panel_toolbox">
                           <a href="<?php echo e(route('product.index')); ?>" class="btn btn-success" data-toggle="tooltip" data-placement="left" title="" data-original-title="List View"><i class="fa fa-reply-all"></i></a>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <!-- content starts here -->
                        <?php echo e(Form::model($data, ['route'=>['product.update', $data->id], 'method'=>'PATCH','enctype' => 'multipart/form-data','files' => 'true'])); ?>

                        <div class="box-body">
                            
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('title', 'Title Product')); ?>

                            <?php echo e(Form::text('title', null, ['class'=>'form-control'])); ?>

                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                        </div>
                            <div class="form-group<?php echo e($errors->has('kategori_id') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('categorys_id', 'Kategori')); ?>

                            <?php echo e(Form::select('categorys_id', $categorys, null, ['class'=>'form-control'])); ?>

                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                        </div>

                        <img width="150" height="90" src="<?php echo e(asset('image/'.$data->image)); ?>">
                        <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('featured_image', '')); ?>

                            <?php echo e(Form::file('featured_image', null, ['class'=>'form-control', 'placeholder'=>''])); ?>

                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                        </div><br/>                            
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('desc', 'Deskripsi')); ?>

                            <?php echo e(Form::textarea('desc', null, ['class'=>'form-control'])); ?>

                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                        </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('price', 'Price')); ?>

                            <?php echo e(Form::text('price', null, ['class'=>'form-control'])); ?>

                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                        </div>
                            <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('status', 'Status')); ?>

                                <select name="status" class="form-control">
                                    <?php if($data->status == 'Draft'): ?>
                                        <option value="Draft">Draft</option>
                                        <option value="Publish">Publish</option>
                                    <?php else: ?>
                                        <option value="Publish">Publish</option>
                                        <option value="Draft">Draft</option>
                                    <?php endif; ?>
                                </select>
                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div>
                           <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('kode', 'Kode')); ?>

                            <?php echo e(Form::text('kode', null, ['class'=>'form-control'])); ?>

                            <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                        </div><br/>
                                <?php echo e(Form::submit('Update',['class' => 'btn btn-success'])); ?>

                            </div>
                        <?php echo e(Form::close()); ?>  
                        <!-- content ends here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>