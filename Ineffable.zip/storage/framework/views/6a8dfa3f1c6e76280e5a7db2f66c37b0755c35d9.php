<?php $__env->startSection('content'); ?>

<head>
<title></title>
<script type="text/javascript" src="<?php echo e(asset('tiny\assets\js\tinymce\tinymce.min.js')); ?>"></script>

<script type="text/javascript">
    tinymce.init({
        selector : "textarea",
        invalid_elements : "span"
    });
</script>

</head>
<body>
<div class="right_col" role="main">
 
    <div class="">
        <div class="page-title">
            <div class="title_left greentea">
                <h3>
                    Dashboard <small>Data Product </small>
                </h3>
            </div>
 
            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">
                        <br/><br/>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2 class="greentea">Create Data</h2>
                        <ul class="nav navbar-right panel_toolbox">
                           <a href="<?php echo e(route('product.index')); ?>" class="btn btn-success" data-toggle="tooltip" data-placement="left" title="" data-original-title="List View"><i class="fa fa-reply-all"></i></a>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <!-- content starts here -->
                        <?php echo e(Form::open(['route' => 'product.store','enctype' => 'multipart/form-data','files' => 'true'])); ?>

                            <div class="box-body">
                            <input type="hidden" name="_token" value="<?= csrf_token(); ?>">
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>"> 
                                <?php echo e(Form::label('title','Title')); ?>

                                <?php echo e(Form::text('title','',['class' => 'form-control'])); ?>

                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('subkategori_id') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('categorys_id', 'Category')); ?>

                                    <select name="categorys_id" class="form-control">
                                        <option value="">-- Select Categorys --</option>
                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('featured_image') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('featured_image', 'Product Image')); ?>

                                <?php echo e(Form::file('featured_image', ['class'=>'form-control', 'placeholder'=>''])); ?>

                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div><br/>                            
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>"> 
                                <?php echo e(Form::label('desc','Deskipsi Product')); ?>

                                <?php echo e(Form::textarea('desc','',['class' => 'form-control'])); ?>

                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>"> 
                                <?php echo e(Form::label('price','Price')); ?>

                                <?php echo e(Form::text('price','',['class' => 'form-control'])); ?>

                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('status', 'Status')); ?>

                                <select name="status" class="form-control">
                                    <option value="Draft">Draft</option>
                                    <option value="Publish">Publish</option>
                                </select>
                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>"> 
                                <?php echo e(Form::label('kode','Kode Product')); ?>

                                <?php echo e(Form::text('kode','',['class' => 'form-control'])); ?>

                                <?php echo e($errors->first('', '<p class="help-block"></p>')); ?>

                            </div><br/>
                                <?php echo e(Form::submit('Submit',['class' => 'btn btn-success'])); ?>

                            </div>
                        <?php echo e(Form::close()); ?>  
                        <!-- content ends here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>